import javax.swing.*;

public class CelsiusConverterGUI {
    private JPanel panel1;

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
